import requests
import json

def emotion_detector(text_to_analyze):
    URL = 'https://sn-watson-emotion.labs.skills.network/v1/watson.runtime.nlp.v1/NlpService/EmotionPredict'
    header = {"grpc-metadata-mm-model-id": "emotion_aggregated-workflow_lang_en_stock"}
    input_json = { "raw_document": { "text": text_to_analyze } }
    response = requests.post(URL, json = input_json, headers=header)
    return response.text



# Assuming this is the response text
response_text = '''
{
    "emotions": {
        "anger": 0.0,
        "disgust": 0.0,
        "fear": 0.0,
        "joy": 0.99,
        "sadness": 0.01
    }
}
'''

# Convert the response text into a dictionary
response_dict = json.loads(response_text)

# Extract the required set of emotions
emotions = response_dict['emotions']

# Find the dominant emotion
dominant_emotion = max(emotions, key=emotions.get)

# Print the dominant emotion and its score
print(f"Dominant Emotion: {dominant_emotion}, Score: {emotions[dominant_emotion]}")




class EmotionDetector:
    def __init__(self, response_text):
        self.response_text = response_text

    def extract_emotions(self):
        response_dict = json.loads(self.response_text)
        emotions = response_dict['emotions']
        return emotions

    def find_dominant_emotion(self):
        emotions = self.extract_emotions()
        dominant_emotion = max(emotions, key=emotions.get)
        return dominant_emotion, emotions[dominant_emotion]