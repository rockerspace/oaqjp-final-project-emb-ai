import unittest
from EmotionDetection.emotion_detection import EmotionDetector

class TestEmotionDetection(unittest.TestCase):

    def test_anger(self):
        response_text = '''
        {
            "emotions": {
                "anger": 0.9,
                "disgust": 0.1,
                "fear": 0.0,
                "joy": 0.0,
                "sadness": 0.0
            }
        }
        '''
        detector = EmotionDetector(response_text)
        dominant_emotion, score = detector.find_dominant_emotion()
        self.assertEqual(dominant_emotion, 'anger')
        self.assertAlmostEqual(score, 0.9)

    def test_disgust(self):
        response_text = '''
        {
            "emotions": {
                "anger": 0.1,
                "disgust": 0.9,
                "fear": 0.0,
                "joy": 0.0,
                "sadness": 0.0
            }
        }
        '''
        detector = EmotionDetector(response_text)
        dominant_emotion, score = detector.find_dominant_emotion()
        self.assertEqual(dominant_emotion, 'disgust')
        self.assertAlmostEqual(score, 0.9)

    def test_fear(self):
        response_text = '''
        {
            "emotions": {
                "anger": 0.0,
                "disgust": 0.0,
                "fear": 0.9,
                "joy": 0.1,
                "sadness": 0.0
            }
        }
        '''
        detector = EmotionDetector(response_text)
        dominant_emotion, score = detector.find_dominant_emotion()
        self.assertEqual(dominant_emotion, 'fear')
        self.assertAlmostEqual(score, 0.9)

    def test_joy(self):
        response_text = '''
        {
            "emotions": {
                "anger": 0.0,
                "disgust": 0.0,
                "fear": 0.0,
                "joy": 0.9,
                "sadness": 0.1
            }
        }
        '''
        detector = EmotionDetector(response_text)
        dominant_emotion, score = detector.find_dominant_emotion()
        self.assertEqual(dominant_emotion, 'joy')
        self.assertAlmostEqual(score, 0.9)

    def test_sadness(self):
        response_text = '''
        {
            "emotions": {
                "anger": 0.0,
                "disgust": 0.0,
                "fear": 0.0,
                "joy": 0.1,
                "sadness": 0.9
            }
        }
        '''
        detector = EmotionDetector(response_text)
        dominant_emotion, score = detector.find_dominant_emotion()
        self.assertEqual(dominant_emotion, 'sadness')
        self.assertAlmostEqual(score, 0.9)

if __name__ == '__main__':
    unittest.main()