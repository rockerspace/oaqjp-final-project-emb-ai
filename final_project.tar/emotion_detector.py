def emotion_detector(response_text):
    try:
        detector = EmotionDetector(response_text)
        emotions = detector.extract_emotions()
        dominant_emotion, score = detector.find_dominant_emotion()
        emotions['dominant_emotion'] = dominant_emotion
        return emotions
    except Exception as e:
        if response_text == '':
            return {'anger': None, 'disgust': None, 'fear': None, 'joy': None, 'sadness': None, 'dominant_emotion': None}
        else:
            raise e