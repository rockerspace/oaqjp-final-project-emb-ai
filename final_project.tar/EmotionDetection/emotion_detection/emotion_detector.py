import json

class EmotionDetector:
    def __init__(self, response_text):
        self.response_text = response_text

    def extract_emotions(self):
        response_dict = json.loads(self.response_text)
        emotions = response_dict['emotions']
        return emotions

    def find_dominant_emotion(self):
        emotions = self.extract_emotions()
        dominant_emotion = max(emotions, key=emotions.get)
        return dominant_emotion, emotions[dominant_emotion]