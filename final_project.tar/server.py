from flask import Flask, request, jsonify, render_template
from EmotionDetection.emotion_detection import EmotionDetector

app = Flask(__name__)  # Define the 'app' variable

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/emotionDetector', methods=['POST'])
def emotion_detector():
    statement = request.form['statement']
    if statement == '':
        return jsonify({'error': 'Invalid text! Please try again!'}), 400
    response_text = '''
    {
        "emotions": {
            "anger": 0.0,
            "disgust": 0.0,
            "fear": 0.0,
            "joy": 0.0,
            "sadness": 0.0
        }
    }
    '''
    detector = EmotionDetector(response_text)
    emotions = detector.extract_emotions()
    dominant_emotion, score = detector.find_dominant_emotion()
    if dominant_emotion is None:
        return jsonify({'error': 'Invalid text! Please try again!'}), 400
    emotions['dominant_emotion'] = dominant_emotion
    return jsonify(emotions)

if __name__ == '__main__':
    app.run(debug=True)